<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<meta http-equiv=content-type content="text/html; charset=utf-8">
<html>
<head>
<title>admin</title>
<style>
body{font-family: Verdana; font-size: 10pt;}
</style>
</head>
<body>
<br><br><br><br>
<center>
<fieldset><legend>ERRORE login</legend>
      <form name=login action=valida.php method=post>
      <p><b>username</b><br><input name="nu"> </p>
      <p><b>password</b><br><input type=password name="ps">
      <p><input class=login type=submit value="login" name=submit>
      </form>
</fieldset>
</center>
</body>
</html>