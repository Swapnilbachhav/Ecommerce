// EN lang variables

tinyMCE.addToLang('',{
help_button_title : 'Help (Alt+h)'
});
